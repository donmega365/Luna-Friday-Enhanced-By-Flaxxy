package com.luna.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

object Contacts {
    private data class PhoneRow(val contactId: Long, val name: String, val number: String, val superPrimary: Boolean, val primary: Boolean)

    private fun ok(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun normName(value: String): String = value
        .lowercase()
        .trim()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun cacheKey(name: String) = "contact_alias_" + normName(name).replace(' ', '_').take(80)

    fun names(c: Context): List<String> {
        if (!ok(c)) return emptyList()
        val names = linkedSetOf<String>()
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    cur.getString(0)?.trim()?.takeIf { it.isNotBlank() }?.let { names.add(it) }
                }
            }
        } catch (_: Exception) {
        }
        return names.toList()
    }

    fun nameFor(c: Context, number: String): String? {
        if (!ok(c)) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0)?.takeIf { name -> name.isNotBlank() } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Resolves exact names first. Partial-name resolution is allowed only when it points to one
     * distinct contact name, avoiding the old behaviour of silently selecting an arbitrary row.
     * Successful user phrases are cached locally so nicknames/aliases used once can be reused.
     */
    fun numberFor(c: Context, name: String): String? {
        if (!ok(c)) return null
        val queryName = name.trim().trim('"', '\'')
        if (queryName.isBlank()) return null

        val cacheKey = cacheKey(queryName)
        Prefs.get(c, cacheKey).takeIf { it.isNotBlank() }?.let { return it }

        val rows = mutableListOf<PhoneRow>()
        try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY,
                ContactsContract.CommonDataKinds.Phone.IS_PRIMARY
            )
            val selection = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?"
            val safeName = queryName.replace("%", "").replace("_", "")
            c.contentResolver.query(uri, projection, selection, arrayOf("%$safeName%"), null)?.use { cur ->
                while (cur.moveToNext()) {
                    val contactId = cur.getLong(0)
                    val display = cur.getString(1)?.trim().orEmpty()
                    val number = cur.getString(2)?.trim().orEmpty()
                    if (display.isNotBlank() && number.isNotBlank()) {
                        rows.add(PhoneRow(contactId, display, number, cur.getInt(3) == 1, cur.getInt(4) == 1))
                    }
                }
            }
        } catch (_: Exception) {
            return null
        }
        if (rows.isEmpty()) return null

        val wanted = normName(queryName)
        val exact = rows.filter { normName(it.name) == wanted }
        val chosen = when {
            exact.isNotEmpty() -> exact
            else -> {
                val matchingNames = rows.map { it.name }.distinctBy { normName(it) }
                if (matchingNames.size != 1) return null
                rows.filter { normName(it.name) == normName(matchingNames.first()) }
            }
        }
        // Two different people can share a display name; do not silently pick one of them.
        if (chosen.map { it.contactId }.distinct().size > 1) return null
        val best = chosen.sortedWith(
            compareByDescending<PhoneRow> { it.superPrimary }
                .thenByDescending { it.primary }
                .thenBy { it.number }
        ).firstOrNull() ?: return null

        Prefs.put(c, cacheKey, best.number)
        // Also remember the canonical name, so a nickname resolved once can be inspected later.
        Prefs.put(c, cacheKey + "_display", best.name)
        return best.number
    }
}
