package com.luna.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Small REST client for the supported AI providers. API keys are read from local settings, never embedded in the APK. */
object AiClient {
    class P(val id: String, val label: String, val url: String, val model: String, val type: String)

    val providers = listOf(
        P("claude", "Claude (Anthropic)", "https://api.anthropic.com/v1/messages", "claude-sonnet-5", "claude"),
        P("openai", "ChatGPT (OpenAI)", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini", "openai"),
        P("gemini", "Gemini (Google)", "https://generativelanguage.googleapis.com/v1beta/models/", "gemini-3.8-flash", "gemini"),
        P("groq", "Groq", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "openai"),
        P("openrouter", "OpenRouter (many models)", "https://openrouter.ai/api/v1/chat/completions", "openai/gpt-4o-mini", "openai"),
        P("deepseek", "DeepSeek", "https://api.deepseek.com/chat/completions", "deepseek-chat", "openai"),
        P("custom", "Custom (OpenAI-compatible)", "", "", "openai")
    )

    fun find(id: String): P = providers.firstOrNull { it.id == id } ?: providers[0]

    /** Current model shown in Settings, including migration of known retired defaults. */
    fun configuredModel(c: Context, providerId: String): String = resolveModel(c, find(providerId))

    fun chat(c: Context, history: List<Pair<String, String>>, system: String): String {
        val p = find(Prefs.get(c, "provider", "claude"))
        val key = Prefs.get(c, "key_" + p.id).trim()
        if (key.isBlank()) return "No API key is saved for ${p.label}. Open Settings and add your own key."

        val model = resolveModel(c, p)
        val rawUrl = if (p.id == "custom") Prefs.get(c, "custom_url").trim() else p.url
        val url = if (p.id == "custom") normalizeCustomUrl(rawUrl) else rawUrl
        if (url.isBlank()) return "Add the custom OpenAI-compatible endpoint in Settings."

        return try {
            when (p.type) {
                "claude" -> {
                    val msgs = JSONArray()
                    history.filter { it.first == "user" || it.first == "assistant" }.forEach {
                        msgs.put(JSONObject().put("role", it.first).put("content", it.second))
                    }
                    val body = JSONObject()
                        .put("model", model)
                        .put("max_tokens", 1200)
                        .put("system", system)
                        .put("messages", msgs)
                    val r = JSONObject(post(url, claudeHeaders(c, key), body.toString()))
                    val content = r.optJSONArray("content") ?: JSONArray()
                    (0 until content.length()).mapNotNull { i ->
                        content.optJSONObject(i)?.takeIf { it.optString("type") == "text" }?.optString("text")
                    }.filter { it.isNotBlank() }.joinToString("\n").ifBlank {
                        "Claude returned an empty response. Try again or select a different model."
                    }
                }
                "gemini" -> {
                    val contents = JSONArray()
                    history.filter { it.first == "user" || it.first == "assistant" }.forEach {
                        val role = if (it.first == "assistant") "model" else "user"
                        contents.put(
                            JSONObject().put("role", role)
                                .put("parts", JSONArray().put(JSONObject().put("text", it.second)))
                        )
                    }
                    val body = JSONObject()
                        .put("contents", contents)
                        .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    val endpoint = url + model.removePrefix("models/") + ":generateContent?key=" + URLEncoder.encode(key, "UTF-8")
                    val r = JSONObject(post(endpoint, emptyMap(), body.toString()))
                    val candidates = r.optJSONArray("candidates")
                    val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                        ?: return "Gemini returned no text. Check your API key, model access and safety filters."
                    (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text") }
                        .filter { it.isNotBlank() }.joinToString("\n").ifBlank {
                            "Gemini returned an empty response. Try again."
                        }
                }
                else -> {
                    val msgs = JSONArray()
                    msgs.put(JSONObject().put("role", "system").put("content", system))
                    history.filter { it.first == "user" || it.first == "assistant" }.forEach {
                        msgs.put(JSONObject().put("role", it.first).put("content", it.second))
                    }
                    val body = JSONObject().put("model", model).put("messages", msgs)
                    val r = JSONObject(post(url, mapOf("Authorization" to "Bearer $key"), body.toString()))
                    r.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                        ?.takeIf { it.isNotBlank() }
                        ?: "The AI provider returned an empty response. Check the selected model and try again."
                }
            }
        } catch (e: Exception) {
            friendlyError(p, model, e)
        }
    }

    /** Migrate known old defaults without overwriting a user's intentionally selected custom model. */
    private fun resolveModel(c: Context, p: P): String {
        val key = "model_" + p.id
        val saved = Prefs.get(c, key).trim()
        val oldGemini = setOf("gemini-flash-latest", "gemini-2.5-flash", "models/gemini-2.5-flash", "models/gemini-flash-latest")
        val replacement = when {
            p.id == "gemini" && (saved.isBlank() || saved in oldGemini) -> p.model
            p.id == "claude" && (saved.isBlank() || saved == "claude-sonnet-5-5") -> p.model
            else -> saved
        }
        if (replacement.isNotBlank() && replacement != saved) Prefs.put(c, key, replacement)
        return replacement.ifBlank { p.model }.removePrefix("models/")
    }

    private fun normalizeCustomUrl(value: String): String {
        val trimmed = value.trim().trimEnd('/')
        if (trimmed.isBlank()) return ""
        return when {
            trimmed.endsWith("/chat/completions", true) -> trimmed
            trimmed.endsWith("/v1", true) -> "$trimmed/chat/completions"
            else -> trimmed
        }
    }

    private fun claudeHeaders(c: Context, key: String): Map<String, String> {
        val h = mutableMapOf(
            "x-api-key" to key,
            "anthropic-version" to "2023-06-01"
        )
        val ws = Prefs.get(c, "ws_claude").trim()
        if (ws.isNotEmpty()) h["anthropic-workspace-id"] = ws
        return h
    }

    private fun friendlyError(p: P, model: String, e: Exception): String {
        val raw = e.message.orEmpty()
        val body = raw.substringAfter(": ", raw)
        val serverMessage = try {
            val j = JSONObject(body)
            j.optJSONObject("error")?.optString("message")
                ?.takeIf { it.isNotBlank() }
                ?: j.optJSONObject("error")?.optJSONObject("error")?.optString("message")
                ?: j.optString("message").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }.orEmpty()
        val lower = serverMessage.lowercase()
        val code = Regex("HTTP (\\d{3})").find(raw)?.groupValues?.getOrNull(1)

        if (p.id == "claude" && (lower.contains("not scoped to a workspace") || lower.contains("workspace-id"))) {
            return "Claude rejected this API request because it needs a valid workspace. In Settings, enter the real Workspace ID from your Anthropic Console, or use an API key scoped to that workspace. Do not guess the ID."
        }
        if (p.id == "gemini" && (lower.contains("no longer available") || lower.contains("not found") || lower.contains("not supported"))) {
            return "Gemini model '$model' is unavailable for this API key. The app has migrated its old default to '${find("gemini").model}'. Open Settings, keep Gemini selected, and check the Model field. Details: ${serverMessage.take(220)}"
        }
        if (serverMessage.isNotBlank()) {
            return "${p.label} request failed${if (code != null) " (HTTP $code)" else ""}: ${serverMessage.take(280)}"
        }
        return "Couldn't reach ${p.label}${if (code != null) " (HTTP $code)" else ""}. Check your internet connection, API endpoint and key. ${raw.take(180)}".trim()
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val con = (URL(url).openConnection() as HttpURLConnection)
        try {
            con.requestMethod = "POST"
            con.connectTimeout = 15000
            con.readTimeout = 60000
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            con.setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
            con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw Exception("HTTP $code: ${txt.take(1600)}")
            return txt
        } finally {
            con.disconnect()
        }
    }
}
