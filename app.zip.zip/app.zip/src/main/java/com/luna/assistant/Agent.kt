package com.luna.assistant

import org.json.JSONObject

// Turns an AI reply like {"action":"whatsapp_send","to":"Ali","text":"..."} into a real command.
object Agent {
    val PROMPT = "You can control the user's phone. When the user asks you to DO something, reply with ONLY one JSON object and no other text, " +
        "for example {\"action\":\"whatsapp_send\",\"to\":\"Muzammil\",\"text\":\"I'm out, back in 5-10 minutes\"}. " +
        "Actions: whatsapp_send(to,text), sms_send(to,text), call(to), open_app(app), torch(value on|off), busy(value on|off), " +
        "alarm(value HH:MM 24h), timer(value seconds), volume(value up|down|max|mute|0-100), brightness(value 1-100), " +
        "search(query), youtube(query), navigate(query), read_sms. 'to' is the contact name exactly as the user said it. " +
        "Write 'text' in the language the user wants the message in. For anything else, just chat normally. " +
        "Never say you did an action yourself in plain text; the app performs it after your JSON."

    fun parse(r: String): Cmd? {
        val s = r.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a < 0 || b <= a || a > 20) return null
        return try {
            val o = JSONObject(s.substring(a, b + 1))
            val to = o.optString("to")
            val text = o.optString("text")
            val value = o.optString("value").lowercase()
            when (o.optString("action").lowercase()) {
                "whatsapp_send" -> if (to.isNotBlank() && text.isNotBlank()) Cmd("wamsg", to, text) else null
                "sms_send" -> if (to.isNotBlank() && text.isNotBlank()) Cmd("sms", to, text) else null
                "call" -> if (to.isNotBlank()) Cmd("call", to.lowercase()) else null
                "open_app" -> Cmd("open", o.optString("app").lowercase())
                "torch" -> Cmd("torch", if (value == "off") "off" else "on")
                "busy" -> Cmd("busy", if (value == "off") "off" else "on")
                "alarm" -> if (value.contains(":")) Cmd("alarm", value) else null
                "timer" -> Cmd("timer", value.filter { it.isDigit() }.ifEmpty { "60" })
                "volume" -> Cmd("volume", value.ifEmpty { "up" })
                "brightness" -> Cmd("brightness", value.filter { it.isDigit() }.ifEmpty { "50" })
                "search" -> Cmd("search", o.optString("query"))
                "youtube" -> Cmd("youtube", o.optString("query"))
                "navigate" -> Cmd("navigate", o.optString("query"))
                "read_sms" -> Cmd("readsms")
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }
}
