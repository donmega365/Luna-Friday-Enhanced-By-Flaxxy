package com.luna.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.telephony.SmsManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

object C {
    val bg = 0xFF0B0F1A.toInt()
    val card = 0xFF141B2D.toInt()
    val line = 0xFF243049.toInt()
    val accent = 0xFF6C8CFF.toInt()
    val text = 0xFFEAF0FF.toInt()
    val sub = 0xFF8A94B2.toInt()
}

class AppRow(
    val label: String,
    val pkg: String,
    val system: Boolean,
    val perms: List<Pair<String, Boolean>>,
    val lastUsed: Long
)

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private lateinit var tabBar: LinearLayout
    private var current = 0
    private var lang = "en"
    private val history = mutableListOf<Pair<String, String>>()
    private val msgs = mutableListOf<Pair<Boolean, String>>()
    private var chatBox: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private val permQueue = ArrayDeque<String>()
    private var sr: SpeechRecognizer? = null
    private var appsCache: List<AppRow>? = null
    private val tabNames = listOf("💬 Chat", "🌙 Busy", "🛡 Access", "📱 Apps", "⚙ Settings")

    // ---------- helpers ----------
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun tr(key: String, vararg a: Any): String = L.t(lang, key, *a)

    private fun shape(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun tv(t: String, size: Float = 15f, color: Int = C.text, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    private fun btn(t: String, small: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = shape(C.accent, 14)
        if (small) {
            b.minWidth = 0
            b.minimumWidth = 0
            b.minHeight = 0
            b.minimumHeight = 0
            b.setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun edit(hint: String, value: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(C.text)
        e.setHintTextColor(C.sub)
        e.background = shape(C.card, 12, C.line)
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        return e
    }

    private fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = label
        s.setTextColor(C.text)
        s.isChecked = checked
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        return s
    }

    private fun lp(top: Int = 0, bottom: Int = 10): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(-1, -2)
        p.topMargin = dp(top)
        p.bottomMargin = dp(bottom)
        return p
    }

    private fun page(views: List<View>): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(24))
        views.forEach { col.addView(it, lp()) }
        val s = ScrollView(this)
        s.addView(col)
        return s
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(n) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.bg
        window.navigationBarColor = C.card
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.bg)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        tabBar = LinearLayout(this)
        tabBar.setBackgroundColor(C.card)
        root.addView(tabBar, LinearLayout.LayoutParams(-1, dp(58)))
        setContentView(root)
        lang = L.code(Prefs.get(this, "lang", "en-US"))
        Speaker.init(this)
        show(0)
    }

    override fun onResume() {
        super.onResume()
        if (current == 2 || current == 1) show(current)
    }

    override fun onDestroy() {
        sr?.destroy()
        super.onDestroy()
    }

    private fun show(i: Int) {
        current = i
        content.removeAllViews()
        val v = when (i) {
            0 -> chatView()
            1 -> busyView()
            2 -> accessView()
            3 -> appsView()
            else -> settingsView()
        }
        content.addView(v)
        tabBar.removeAllViews()
        tabNames.forEachIndexed { idx, n ->
            val t = tv(n, 11f, if (idx == i) C.accent else C.sub, idx == i)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { show(idx) }
            tabBar.addView(t, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    // ---------- CHAT ----------
    private fun bubbleView(text: String, me: Boolean): View {
        val t = tv(text, 15f, if (me) Color.WHITE else C.text)
        t.background = shape(if (me) C.accent else C.card, 18)
        t.setPadding(dp(14), dp(10), dp(14), dp(10))
        t.maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
        val w = LinearLayout(this)
        w.gravity = if (me) Gravity.END else Gravity.START
        w.addView(t)
        return w
    }

    private fun say(text: String, me: Boolean, speak: Boolean = true) {
        msgs.add(Pair(me, text))
        chatBox?.addView(bubbleView(text, me), lp(4, 4))
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
        if (!me && speak && Prefs.getBool(this, "speak", true)) Speaker.speak(this, text)
    }

    private fun chatView(): View {
        val name = Prefs.get(this, "name", "Luna")
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        // Compact product-style header: consistent branding, assistant name and clear status.
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(18), dp(14), dp(18), dp(12))
        val mark = tv("✦", 23f, Color.WHITE, true)
        mark.gravity = Gravity.CENTER
        mark.background = shape(C.accent, 15)
        head.addView(mark, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titleGroup = LinearLayout(this)
        titleGroup.orientation = LinearLayout.VERTICAL
        titleGroup.setPadding(dp(12), 0, 0, 0)
        titleGroup.addView(tv(name, 21f, C.text, true))
        titleGroup.addView(tv("PERSONAL ASSISTANT  ·  PHONE CONTROL", 9.5f, C.sub, true))
        head.addView(titleGroup, LinearLayout.LayoutParams(0, -2, 1f))
        val isOnline = online()
        val status = tv(if (isOnline) "● ONLINE" else "● OFFLINE", 10f, if (isOnline) 0xFF78D6AC.toInt() else C.sub, true)
        status.background = shape(C.card, 12, C.line)
        status.setPadding(dp(10), dp(8), dp(10), dp(8))
        head.addView(status)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(6), dp(12), dp(6))
        val sc = ScrollView(this)
        sc.addView(box)
        chatBox = box
        chatScroll = sc
        root.addView(head)
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        box.addView(bubbleView(tr("greet", name), false), lp(4, 4))
        msgs.forEach { box.addView(bubbleView(it.second, it.first), lp(4, 4)) }
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(10), dp(8), dp(10), dp(8))
        val input = edit("Talk or type to $name...", "")
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setOnEditorActionListener { _, _, _ ->
            val t = input.text.toString()
            input.setText("")
            send(t)
            true
        }
        val mic = btn("🎤", true) { listen() }
        val go = btn("➤", true) {
            val t = input.text.toString()
            input.setText("")
            send(t)
        }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        val bp = LinearLayout.LayoutParams(dp(48), dp(46))
        bp.leftMargin = dp(6)
        bar.addView(mic, bp)
        val gp = LinearLayout.LayoutParams(dp(48), dp(46))
        gp.leftMargin = dp(6)
        bar.addView(go, gp)
        root.addView(bar)
        return root
    }

    private fun systemPrompt(): String {
        val name = Prefs.get(this, "name", "Luna")
        val sel = Langs.list.firstOrNull { it.second == Prefs.get(this, "lang", "en-US") }?.first ?: "English (US)"
        return "You are $name, a friendly Jarvis-like voice assistant on the user's phone. " +
            "Default language is $sel. If the user writes or speaks in another language (Hindi, Urdu, Arabic, Hinglish, etc.), " +
            "reply in that same language and script. When the user switches language, switch with them. " +
            "Keep answers short and natural for speaking. Never ask for or reveal OTPs, passwords or card numbers. " + Agent.PROMPT
    }

    private fun send(text0: String) {
        val text = text0.trim()
        if (text.isEmpty()) return
        lang = L.detect(this, text)
        say(text, true)
        val knownContacts = if (Commands.needsContactNames(text)) Contacts.names(this) else emptyList()
        val cmd = Commands.parse(text, knownContacts)
        if (cmd != null) {
            runCmd(cmd)
            return
        }
        if (!online()) {
            say(tr("offline"), false)
            return
        }
        history.add(Pair("user", text))
        val tb = bubbleView("...", false)
        chatBox?.addView(tb, lp(4, 4))
        Thread {
            val r = AiClient.chat(this, history.takeLast(12), systemPrompt())
            runOnUiThread {
                chatBox?.removeView(tb)
                val act = Agent.parse(r)
                if (act != null) {
                    history.add(Pair("assistant", "(done: " + act.kind + ")"))
                    runCmd(act)
                } else {
                    history.add(Pair("assistant", r))
                    say(r, false)
                }
            }
        }.start()
    }

    private fun listen() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Speech recognition is not available on this phone")
            return
        }
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { toast(tr("listening")) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { toast(tr("not_heard", e)) }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onResults(res: Bundle?) {
                val l = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                send(l?.firstOrNull() ?: "")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.get(this, "lang", "en-US"))
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !online())
        r.startListening(i)
    }

    // ---------- COMMANDS ----------
    private fun describe(c: Cmd): String = when (c.kind) {
        "open" -> tr("q_open", c.a)
        "torch" -> tr("q_torch", c.a)
        "call" -> tr("q_call", c.a)
        "sms" -> tr("q_sms", c.a, c.b)
        "wamsg" -> tr("q_wamsg", c.a, c.b)
        "busy" -> tr("q_busy", c.a)
        "readsms" -> tr("q_readsms")
        else -> tr("q_generic")
    }

    private fun runCmd(c: Cmd) {
        val risky = c.kind == "call" || c.kind == "sms" || c.kind == "wamsg" || c.kind == "readsms"
        val mode = Prefs.get(this, "mode", "MEDIUM")
        val need = mode == "LOW" || (mode == "MEDIUM" && risky)
        if (need) {
            AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage(describe(c))
                .setPositiveButton("Yes") { _, _ -> safeExec(c) }
                .setNegativeButton("No") { _, _ -> say(tr("cancelled"), false) }
                .show()
        } else {
            safeExec(c)
        }
    }

    private fun numberOf(q: String): String? {
        val digits = q.count { it.isDigit() }
        if (digits >= 5 && q.count { it.isLetter() } == 0) return q
        return Contacts.numberFor(this, q)
    }

    private fun launchApp(a: AppMatcher.A) {
        val li = packageManager.getLaunchIntentForPackage(a.pkg)
        if (li == null) {
            say(tr("app_nf", a.label), false)
        } else {
            say(tr("opening", a.label), false)
            startActivity(li)
        }
    }

    private fun safeExec(c: Cmd) {
        try {
            exec(c)
        } catch (e: Exception) {
            say(tr("error", e.message ?: "unknown"), false)
        }
    }

    private fun exec(c: Cmd) {
        when (c.kind) {
            "open" -> {
                val found = AppMatcher.find(packageManager, c.a)
                val saved = Prefs.get(this, "appchoice_" + AppMatcher.norm(c.a))
                val pick = found.firstOrNull { it.pkg == saved }
                when {
                    pick != null -> launchApp(pick)
                    found.isEmpty() -> say(tr("app_nf", c.a), false)
                    found.size == 1 -> launchApp(found[0])
                    else -> {
                        AlertDialog.Builder(this)
                            .setTitle(tr("q_open", c.a))
                            .setItems(found.map { it.label }.toTypedArray()) { _, which ->
                                Prefs.put(this, "appchoice_" + AppMatcher.norm(c.a), found[which].pkg)
                                launchApp(found[which])
                            }
                            .show()
                    }
                }
            }
            "torch" -> {
                val cm = getSystemService(CameraManager::class.java)
                cm.setTorchMode(cm.cameraIdList[0], c.a == "on")
                say(tr("torch_done", c.a), false)
            }
            "call" -> {
                val n = numberOf(c.a)
                if (n == null) {
                    say(tr("num_nf", c.a), false)
                } else {
                    val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
                    say(tr("calling", c.a), false)
                    startActivity(Intent(action, Uri.parse("tel:" + n)))
                }
            }
            "sms" -> {
                val n = numberOf(c.a)
                if (n == null || !granted(Manifest.permission.SEND_SMS)) {
                    say(tr("sms_fail"), false)
                } else {
                    SmsManager.getDefault().sendTextMessage(n, null, c.b, null, null)
                    say(tr("sms_ok"), false)
                }
            }
            "wamsg" -> {
                val n = numberOf(c.a)
                if (n == null) {
                    say(tr("num_nf", c.a), false)
                } else if (!WaSender.send(this, n, c.b)) {
                    say(tr("wa_missing"), false)
                } else if (WaSender.accessibilityOn(this)) {
                    say(tr("wa_sending", c.a), false)
                } else {
                    say(tr("wa_open", c.a), false)
                }
            }
            "readsms" -> {
                var shown = false
                if (granted(Manifest.permission.READ_SMS)) {
                    contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body"), null, null, "date DESC")?.use {
                        if (it.moveToFirst()) {
                            val addr = it.getString(0) ?: "?"
                            val who = Contacts.nameFor(this, addr) ?: addr
                            say(tr("sms_last", who, it.getString(1) ?: ""), false)
                            shown = true
                        }
                    }
                }
                if (!shown) say(tr("sms_none"), false)
            }
            "busy" -> {
                Prefs.putBool(this, "busy", c.a == "on")
                say(tr("busy_set", c.a), false)
            }
            "volume" -> {
                val am = getSystemService(AudioManager::class.java)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                when (c.a) {
                    "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down", "low" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "max", "full" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
                    "mute" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                    else -> {
                        val pct = (c.a.toIntOrNull() ?: 50).coerceIn(0, 100)
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, max * pct / 100, AudioManager.FLAG_SHOW_UI)
                    }
                }
                say(tr("vol_ok"), false)
            }
            "brightness" -> {
                val pct = (c.a.toIntOrNull() ?: 50).coerceIn(1, 100)
                if (Settings.System.canWrite(this)) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * pct / 100).coerceIn(1, 255))
                    say(tr("bright_ok", pct), false)
                } else {
                    say(tr("need_write"), false)
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
                }
            }
            "alarm" -> {
                val parts = c.a.split(":")
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                i.putExtra(AlarmClock.EXTRA_HOUR, parts[0].toInt())
                i.putExtra(AlarmClock.EXTRA_MINUTES, parts[1].toInt())
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                startActivity(i)
                say(tr("alarm_ok", String.format("%02d:%02d", parts[0].toInt(), parts[1].toInt())), false)
            }
            "timer" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                i.putExtra(AlarmClock.EXTRA_LENGTH, c.a.toInt())
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                startActivity(i)
                say(tr("timer_ok"), false)
            }
            "battery" -> {
                val bm = getSystemService(BatteryManager::class.java)
                say(tr("battery", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)), false)
            }
            "time" -> {
                val d = Date()
                say(tr("time_now", DateFormat.getTimeInstance(DateFormat.SHORT).format(d) + ", " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(d)), false)
            }
            "search" -> {
                say(tr("searching", c.a), false)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(c.a))))
            }
            "youtube" -> {
                say(tr("searching", c.a), false)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(c.a))))
            }
            "navigate" -> {
                say(tr("navigating", c.a), false)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(c.a))))
            }
            "settings" -> {
                val act = when (c.a) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    else -> Settings.ACTION_SOUND_SETTINGS
                }
                startActivity(Intent(act))
            }
        }
    }

    // ---------- BUSY ----------
    private fun statusLines(): String {
        fun f(ok: Boolean, t: String) = (if (ok) "✅ " else "❌ ") + t
        val pw = getSystemService(PowerManager::class.java)
        return listOf(
            f(Prefs.getBool(this, "busy"), "Busy mode is ON"),
            f(listenerOn(), "Notification access is enabled"),
            f(Prefs.getList(this, "busy_friends").isNotEmpty(), "Friends list for auto-reply is set"),
            f(granted(Manifest.permission.READ_CONTACTS), "Contacts permission"),
            f(granted(Manifest.permission.SEND_SMS), "SMS permission"),
            f(granted(Manifest.permission.ANSWER_PHONE_CALLS), "Answer/end calls permission"),
            f(granted(Manifest.permission.READ_CALL_LOG), "Call log permission (caller number)"),
            f(granted(Manifest.permission.READ_PHONE_STATE), "Phone state permission"),
            f(WaSender.accessibilityOn(this), "WhatsApp auto-send (Accessibility) enabled"),
            f(Settings.canDrawOverlays(this), "Display over other apps (lets calls open WhatsApp)"),
            f(pw.isIgnoringBatteryOptimizations(packageName), "Battery unrestricted (keeps the assistant alive)")
        ).joinToString("\n")
    }

    private fun busyView(): View {
        val a = this
        val views = mutableListOf<View>()
        views.add(tv("Busy mode", 22f, C.text, true))
        views.add(sw("Busy mode ON", Prefs.getBool(a, "busy")) { Prefs.putBool(a, "busy", it) })
        views.add(tv("While busy, if one of the friends below messages you, the assistant sends them your auto-reply.", 13f, C.sub))
        val msg = edit("Auto-reply message", Prefs.get(a, "busy_msg", Defaults.MSG))
        views.add(msg)
        val friends = edit("Friends' names, comma separated (e.g. Rahul, Ali)", Prefs.getList(a, "busy_friends").joinToString(", "))
        views.add(friends)
        views.add(tv("Write each name exactly as it appears in your WhatsApp / Contacts notification. Group chats are skipped.", 12f, C.sub))
        views.add(tv("Call pick list", 18f, C.text, true))
        val calls = edit("Whose calls to handle (empty = same as friends above)", Prefs.getList(a, "call_friends").joinToString(", "))
        views.add(calls)
        val callMsg = edit("Message for callers, e.g. Muzammil Sir is out, back in 5-10 min", Prefs.get(a, "call_msg"))
        views.add(callMsg)
        val rg = RadioGroup(a)
        val r1 = RadioButton(a)
        r1.id = 201
        r1.text = "Reject the call and send an SMS"
        r1.setTextColor(C.text)
        val r3 = RadioButton(a)
        r3.id = 203
        r3.text = "Reject the call and send a WhatsApp message (needs auto-send)"
        r3.setTextColor(C.text)
        val r2 = RadioButton(a)
        r2.id = 202
        r2.text = "Answer and speak the message on speaker (caller may hear it faintly)"
        r2.setTextColor(C.text)
        rg.addView(r1)
        rg.addView(r3)
        rg.addView(r2)
        rg.check(
            when (Prefs.get(a, "call_action", "sms")) {
                "answer" -> 202
                "wa" -> 203
                else -> 201
            }
        )
        views.add(rg)
        views.add(btn("💾 Save") {
            Prefs.put(a, "busy_msg", msg.text.toString().ifBlank { Defaults.MSG })
            Prefs.putList(a, "busy_friends", friends.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() })
            Prefs.putList(a, "call_friends", calls.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() })
            Prefs.put(a, "call_msg", callMsg.text.toString().trim())
            Prefs.put(
                a, "call_action",
                when (rg.checkedRadioButtonId) {
                    202 -> "answer"
                    203 -> "wa"
                    else -> "sms"
                }
            )
            toast("Saved ✅")
            show(1)
        })
        views.add(btn("🔔 Turn on Notification access (required)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        views.add(btn("🧪 Test auto-reply (fake message from your first friend)") {
            SelfTest.run(a)
            toast("Test sent. Wait 5 seconds, then tap Refresh.")
        })
        views.add(tv("Status checklist", 18f, C.text, true))
        views.add(tv(statusLines(), 14f, C.text))
        views.add(tv("Activity log (why a reply was or wasn't sent)", 18f, C.text, true))
        views.add(tv(AppLog.text(a), 12f, C.sub))
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(btn("Refresh", true) { show(1) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        row.addView(btn("Clear log", true) {
            AppLog.clear(a)
            show(1)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        views.add(row)
        return page(views)
    }

    // ---------- ACCESS ----------
    private fun permList(): List<Triple<String, String, String>> {
        val l = mutableListOf(
            Triple("Microphone", Manifest.permission.RECORD_AUDIO, "Voice commands"),
            Triple("Contacts", Manifest.permission.READ_CONTACTS, "Recognize your friends' names and numbers"),
            Triple("Phone state", Manifest.permission.READ_PHONE_STATE, "Detect incoming calls"),
            Triple("Call log", Manifest.permission.READ_CALL_LOG, "See the caller's number"),
            Triple("Answer / end calls", Manifest.permission.ANSWER_PHONE_CALLS, "Pick up or reject calls"),
            Triple("Make calls", Manifest.permission.CALL_PHONE, "'call Rahul' command"),
            Triple("Send SMS", Manifest.permission.SEND_SMS, "SMS replies and commands"),
            Triple("Read SMS", Manifest.permission.READ_SMS, "'read my last SMS' command")
        )
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Triple("Notifications", "android.permission.POST_NOTIFICATIONS", "Show scam alerts"))
        }
        return l
    }

    private fun listenerOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s?.contains(packageName) == true
    }

    private fun usageOn(): Boolean {
        return try {
            val ops = getSystemService(AppOpsManager::class.java)
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) ==
                AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    private fun nextPerm() {
        if (permQueue.isEmpty()) {
            if (current == 2) show(2)
            return
        }
        val p = permQueue.removeFirst()
        if (granted(p)) nextPerm() else requestPermissions(arrayOf(p), 10)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(rc, p, g)
        nextPerm()
    }

    private fun appSettings(pkg: String = packageName) {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)))
    }

    private fun revoke(perms: List<String>) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                revokeSelfPermissionsOnKill(perms)
            } else if (Build.VERSION.SDK_INT >= 33) {
                perms.forEach { revokeSelfPermissionOnKill(it) }
            }
        } catch (_: Exception) {
        }
        toast("To remove a permission, turn it off in Settings > Permissions.")
        appSettings()
    }

    private fun special(label: String, desc: String, on: Boolean, intent: () -> Intent): Switch {
        val s = Switch(this)
        s.text = label + "\n" + desc
        s.setTextColor(C.text)
        s.isChecked = on
        s.setOnClickListener { startActivity(intent()) }
        return s
    }

    private fun accessView(): View {
        val a = this
        val views = mutableListOf<View>()
        views.add(tv("Security mode", 22f, C.text, true))
        val modes = listOf(
            Pair("LOW", "LOW: asks you before every action (safest)"),
            Pair("MEDIUM", "MEDIUM: acts on its own, confirms important actions (call / SMS)"),
            Pair("HARD", "HARD: does everything with no confirmation ⚠")
        )
        val cur = Prefs.get(a, "mode", "MEDIUM")
        val rg = RadioGroup(a)
        modes.forEachIndexed { i, m ->
            val rb = RadioButton(a)
            rb.id = 100 + i
            rb.text = m.second
            rb.setTextColor(C.text)
            rg.addView(rb)
            if (m.first == cur) rg.check(100 + i)
        }
        rg.setOnCheckedChangeListener { _, id -> if (id >= 100) Prefs.put(a, "mode", modes[id - 100].first) }
        views.add(rg)

        views.add(tv("Permissions (one by one)", 20f, C.text, true))
        views.add(tv("Turn a switch ON and only that permission is requested. Once allowed it stays after restarts.", 13f, C.sub))
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(btn("Select all", true) {
            permQueue.clear()
            permList().forEach { permQueue.add(it.second) }
            nextPerm()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        row.addView(btn("Deselect all", true) {
            revoke(permList().map { it.second }.filter { granted(it) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        views.add(row)

        permList().forEach { (label, perm, desc) ->
            val s = Switch(a)
            s.text = label + "\n" + desc
            s.setTextColor(C.text)
            s.isChecked = granted(perm)
            s.setOnClickListener {
                if (s.isChecked) {
                    permQueue.clear()
                    requestPermissions(arrayOf(perm), 11)
                } else {
                    revoke(listOf(perm))
                }
            }
            views.add(s)
        }
        views.add(special("Notification access", "Read friends' messages and auto-reply", listenerOn()) {
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        })
        views.add(special("WhatsApp auto-send (Accessibility)", "Presses Send in WhatsApp for messages you ask for. Only sees WhatsApp screens.", WaSender.accessibilityOn(a)) {
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        })
        views.add(special("Display over other apps", "Lets calls and background tasks open WhatsApp", Settings.canDrawOverlays(a)) {
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
        })
        views.add(special("Usage access (all apps info)", "Shows when each app was last used in the Apps tab", usageOn()) {
            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        })
        views.add(special("Modify system settings", "Brightness command", Settings.System.canWrite(a)) {
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName))
        })

        views.add(btn("🔋 Battery: set to unrestricted", true) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        views.add(btn("♻ Stop permission auto-reset (App info)", true) { appSettings() })

        views.add(tv("Scam and privacy guard", 20f, C.text, true))
        views.add(tv("Flags suspicious message patterns and reviews installed-app permissions. This is a helpful warning system, not a full malware scanner.", 12f, C.sub))
        views.add(sw("Scam message alerts", Prefs.getBool(a, "scam_guard", true)) { Prefs.putBool(a, "scam_guard", it) })
        val out = tv("", 13f, C.sub)
        views.add(btn("🔍 Review apps with sensitive permissions") { scanApps(out) })
        views.add(out)
        return page(views)
    }

    private fun scanApps(out: TextView) {
        out.text = "Scanning..."
        Thread {
            val risky = listOf(
                "SEND_SMS", "READ_SMS", "RECEIVE_SMS", "RECORD_AUDIO", "READ_CONTACTS", "CAMERA",
                "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES", "BIND_ACCESSIBILITY_SERVICE",
                "READ_CALL_LOG", "BIND_DEVICE_ADMIN", "ACCESS_FINE_LOCATION"
            )
            val res = mutableListOf<Pair<Int, String>>()
            for (r in loadApps()) {
                if (r.system || r.pkg == packageName) continue
                val n = r.perms.count { q -> risky.any { q.first.endsWith(it) } }
                if (n >= 4) res.add(Pair(n, r.label))
            }
            res.sortByDescending { it.first }
            val txt = if (res.isEmpty()) {
                "✅ No installed apps matched this permission-count heuristic. This does not prove that every app is safe."
            } else {
                "⚠ These apps request several sensitive permissions. Review each app's purpose before deciding whether to keep it:\n\n" +
                    res.take(15).joinToString("\n") { "• ${it.second} (${it.first} risky permissions)" }
            }
            runOnUiThread { out.text = txt }
        }.start()
    }

    // ---------- APPS ----------
    private fun lastUsedMap(): Map<String, Long> {
        val m = HashMap<String, Long>()
        if (!usageOn()) return m
        try {
            val usm = getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            for (u in usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 30L * 86400000L, now)) {
                val old = m[u.packageName] ?: 0L
                if (u.lastTimeUsed > old) m[u.packageName] = u.lastTimeUsed
            }
        } catch (_: Exception) {
        }
        return m
    }

    private fun loadApps(): List<AppRow> {
        appsCache?.let { return it }
        val pm = packageManager
        val used = lastUsedMap()
        val out = mutableListOf<AppRow>()
        try {
            for (p in pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
                val ai = p.applicationInfo ?: continue
                val req = p.requestedPermissions ?: emptyArray()
                val flags = p.requestedPermissionsFlags ?: IntArray(0)
                val perms = req.mapIndexed { i, n ->
                    Pair(n, ((flags.getOrNull(i) ?: 0) and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0)
                }
                out.add(
                    AppRow(
                        ai.loadLabel(pm).toString(), p.packageName,
                        (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0, perms, used[p.packageName] ?: 0L
                    )
                )
            }
        } catch (_: Exception) {
        }
        out.sortBy { it.label.lowercase() }
        appsCache = out
        return out
    }

    private fun ago(t: Long): String {
        if (t <= 0L) return "unknown"
        val m = (System.currentTimeMillis() - t) / 60000
        return when {
            m < 60 -> "${m}m ago"
            m < 1440 -> "${m / 60}h ago"
            else -> "${m / 1440}d ago"
        }
    }

    private fun appDialog(r: AppRow) {
        val sb = StringBuilder()
        sb.append(r.pkg).append("\n")
        sb.append("Last used: ").append(if (usageOn()) ago(r.lastUsed) else "turn on Usage access").append("\n\n")
        if (r.perms.isEmpty()) {
            sb.append("No permissions requested.")
        } else {
            r.perms.sortedByDescending { it.second }.forEach {
                sb.append(if (it.second) "✅ " else "⛔ ").append(it.first.substringAfterLast('.')).append("\n")
            }
        }
        AlertDialog.Builder(this)
            .setTitle(r.label)
            .setMessage(sb.toString())
            .setPositiveButton("App settings") { _, _ -> appSettings(r.pkg) }
            .setNeutralButton("Open app") { _, _ ->
                val li = packageManager.getLaunchIntentForPackage(r.pkg)
                if (li != null) startActivity(li) else toast("This app can't be opened")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun appsView(): View {
        val a = this
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(0))
        root.addView(tv("All apps", 22f, C.text, true), lp(0, 8))
        val search = edit("Search apps...", "")
        root.addView(search, lp(0, 6))
        var showSys = false
        val info = tv("Loading apps...", 13f, C.sub)
        val list = LinearLayout(a)
        list.orientation = LinearLayout.VERTICAL

        fun render() {
            val rows = appsCache ?: return
            val q = search.text.toString().trim().lowercase()
            val f = rows.filter { (showSys || !it.system) && (q.isEmpty() || it.label.lowercase().contains(q) || it.pkg.contains(q)) }
            list.removeAllViews()
            info.text = "Showing ${minOf(f.size, 100)} of ${f.size} apps. Tap an app to see its permissions."
            f.take(100).forEach { r ->
                val gcount = r.perms.count { it.second }
                val card = LinearLayout(a)
                card.orientation = LinearLayout.VERTICAL
                card.background = shape(C.card, 12, C.line)
                card.setPadding(dp(14), dp(10), dp(14), dp(10))
                card.addView(tv(r.label, 15f, C.text, true))
                card.addView(tv("${r.pkg}\n$gcount/${r.perms.size} permissions granted · last used ${ago(r.lastUsed)}", 11f, C.sub))
                card.setOnClickListener { appDialog(r) }
                list.addView(card, lp(0, 6))
            }
        }

        root.addView(sw("Show system apps", false) {
            showSys = it
            render()
        }, lp(0, 6))
        root.addView(info, lp(0, 6))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { render() }
        })
        val sc = ScrollView(a)
        sc.addView(list)
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        if (appsCache != null) {
            render()
        } else {
            Thread {
                loadApps()
                runOnUiThread { render() }
            }.start()
        }
        return root
    }

    // ---------- SETTINGS ----------
    private fun settingsView(): View {
        val a = this
        val views = mutableListOf<View>()
        views.add(tv("Settings", 22f, C.text, true))

        views.add(tv("Assistant name", 16f, C.text, true))
        val name = edit("Name", Prefs.get(a, "name", "Luna"))
        views.add(name)
        val chips = LinearLayout(a)
        chips.orientation = LinearLayout.HORIZONTAL
        listOf("Luna", "Friday", "Jarvis", "Nova").forEach { n ->
            chips.addView(btn(n, true) { name.setText(n) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        }
        views.add(chips)

        views.add(tv("AI provider", 16f, C.text, true))
        views.add(tv("Choose a provider, add your own API key, then use Test AI. Keys are not included in the project ZIP.", 12f, C.sub))
        val pSp = Spinner(a)
        pSp.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, AiClient.providers.map { it.label })
        var prev = AiClient.providers.indexOfFirst { it.id == Prefs.get(a, "provider", "claude") }.coerceAtLeast(0)
        pSp.setSelection(prev)
        views.add(pSp)
        val key = edit("API key", Prefs.get(a, "key_" + AiClient.providers[prev].id))
        key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        views.add(key)
        val model = edit("Model", AiClient.configuredModel(a, AiClient.providers[prev].id))
        views.add(model)
        val curl = edit("Custom endpoint or base URL (OpenAI-compatible only)", Prefs.get(a, "custom_url"))
        views.add(curl)
        val cc = edit("Default country code for numbers without +, e.g. 91 or 92", Prefs.get(a, "cc"))
        views.add(cc)
        val ws = edit("Claude Workspace ID (only if Claude asks for it)", Prefs.get(a, "ws_claude"))
        views.add(ws)
        views.add(tv("For Claude HTTP 400 workspace errors, enter the actual Workspace ID from your Anthropic Console or use an API key scoped to that workspace. Never guess the ID.", 12f, C.sub))
        pSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos == prev) return
                Prefs.put(a, "key_" + AiClient.providers[prev].id, key.text.toString().trim())
                Prefs.put(a, "model_" + AiClient.providers[prev].id, model.text.toString().trim())
                prev = pos
                val np = AiClient.providers[pos]
                key.setText(Prefs.get(a, "key_" + np.id))
                model.setText(AiClient.configuredModel(a, np.id))
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        views.add(tv("Language & voice", 16f, C.text, true))
        views.add(tv("Default is English (US). The assistant automatically answers in whatever language you speak or write (Hindi, Urdu, Arabic, ...). This setting is used for the microphone and the voice.", 12f, C.sub))
        val lSp = Spinner(a)
        lSp.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, Langs.list.map { it.first })
        lSp.setSelection(Langs.list.indexOfFirst { it.second == Prefs.get(a, "lang", "en-US") }.coerceAtLeast(0))
        views.add(lSp)
        val vSp = Spinner(a)
        views.add(vSp)

        fun fillVoices() {
            val vs = Speaker.voicesFor(a)
            val names = listOf("Default voice") + vs.mapIndexed { i, v -> "Voice ${i + 1} · ${v.name}" }
            vSp.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, names)
            val cur = Prefs.get(a, "voice")
            val idx = vs.indexOfFirst { it.name == cur }
            vSp.setSelection(if (idx >= 0) idx + 1 else 0)
        }
        fillVoices()
        lSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val tag = Langs.list[pos].second
                if (tag != Prefs.get(a, "lang", "en-US")) {
                    Prefs.put(a, "lang", tag)
                    Prefs.put(a, "voice", "")
                    lang = L.code(tag)
                    Speaker.applyPrefs(a)
                    fillVoices()
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        vSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val vn = if (pos == 0) "" else (Speaker.voicesFor(a).getOrNull(pos - 1)?.name ?: "")
                Prefs.put(a, "voice", vn)
                Speaker.applyPrefs(a)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        views.add(btn("🔊 Test voice", true) {
            Speaker.speak(a, "Hello, I'm ${name.text}.")
            fillVoices()
        })
        views.add(tv("Want more voices? Phone Settings > Text-to-speech > download Google voices.", 12f, C.sub))
        views.add(sw("Speak replies aloud", Prefs.getBool(a, "speak", true)) { Prefs.putBool(a, "speak", it) })

        fun saveAll() {
            val p = AiClient.providers[pSp.selectedItemPosition]
            Prefs.put(a, "name", name.text.toString().trim().ifBlank { "Luna" })
            Prefs.put(a, "provider", p.id)
            Prefs.put(a, "key_" + p.id, key.text.toString().trim())
            Prefs.put(a, "model_" + p.id, model.text.toString().trim())
            Prefs.put(a, "custom_url", curl.text.toString().trim())
            Prefs.put(a, "ws_claude", ws.text.toString().trim())
            Prefs.put(a, "cc", cc.text.toString().trim())
        }
        views.add(btn("💾 Save") {
            saveAll()
            toast("Saved ✅")
        })
        views.add(btn("🧪 Test AI") {
            saveAll()
            toast("Testing...")
            Thread {
                val r = AiClient.chat(a, listOf(Pair("user", "Say hi in one short line.")), "Be brief.")
                runOnUiThread {
                    val failed = r.contains("failed", true) || r.contains("rejected", true) || r.startsWith("Couldn't", true) || r.startsWith("No API key", true)
                    AlertDialog.Builder(a)
                        .setTitle(if (failed) "AI test needs attention" else "AI test result")
                        .setMessage(r)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }.start()
        })
        return page(views)
    }
}
