package com.luna.assistant

import android.content.Intent
import android.content.pm.PackageManager

object AppMatcher {
    class A(val label: String, val pkg: String)

    // short forms / nicknames -> canonical name
    private val alias = mapOf(
        "wa" to "whatsapp", "whats app" to "whatsapp", "watsapp" to "whatsapp", "whatsap" to "whatsapp",
        "wa business" to "whatsapp business", "business whatsapp" to "whatsapp business",
        "yt" to "youtube", "you tube" to "youtube", "utube" to "youtube",
        "insta" to "instagram", "ig" to "instagram", "fb" to "facebook", "face book" to "facebook",
        "gpay" to "google pay", "g pay" to "google pay", "tg" to "telegram", "snap" to "snapchat",
        "map" to "maps", "google maps" to "maps", "playstore" to "play store", "google play" to "play store",
        "mail" to "gmail", "browser" to "chrome", "setting" to "settings",
        "message" to "messages", "sms" to "messages", "msg" to "messages", "dialer" to "phone",
        "calc" to "calculator", "pics" to "photos", "gallery" to "photos"
    )

    // package hints for apps whose launcher label can differ (e.g. "WA Business")
    private val hints = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "whatsapp business" to listOf("com.whatsapp.w4b"),
        "youtube" to listOf("com.google.android.youtube"),
        "instagram" to listOf("com.instagram.android"),
        "facebook" to listOf("com.facebook.katana"),
        "telegram" to listOf("org.telegram.messenger"),
        "snapchat" to listOf("com.snapchat.android"),
        "chrome" to listOf("com.android.chrome"),
        "gmail" to listOf("com.google.android.gm"),
        "maps" to listOf("com.google.android.apps.maps"),
        "google pay" to listOf("com.google.android.apps.nbu.paisa.user"),
        "play store" to listOf("com.android.vending"),
        "spotify" to listOf("com.spotify.music"),
        "tiktok" to listOf("com.zhiliaoapp.musically"),
        "twitter" to listOf("com.twitter.android"),
        "x" to listOf("com.twitter.android")
    )

    fun norm(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9\\u0900-\\u097f\\u0600-\\u06ff ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    fun find(pm: PackageManager, query: String): List<A> {
        val q0 = norm(query)
        if (q0.isEmpty()) return emptyList()
        val q = alias[q0] ?: q0
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = pm.queryIntentActivities(i, 0)
            .map { A(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }

        val hinted = hints[q]
        if (hinted != null) {
            val r = all.filter { it.pkg in hinted }
            if (r.isNotEmpty()) return r
        }

        val scored = all.map { a ->
            val l = norm(a.label)
            val p = a.pkg.lowercase()
            val s = when {
                l == q -> 100
                l.startsWith(q) -> 80
                l.contains(q) -> 60
                p.contains(q.replace(" ", "")) -> 40
                q.split(" ").all { w -> l.contains(w) || p.contains(w) } -> 30
                else -> 0
            }
            Pair(a, s)
        }.filter { it.second > 0 }
        if (scored.isNotEmpty()) {
            val best = scored.maxOf { it.second }
            return scored.filter { it.second == best }.map { it.first }
        }

        // typo tolerance
        if (q.length >= 4) {
            val fuzzy = all.map { Pair(it, lev(q, norm(it.label))) }.filter { it.second <= 2 }
            if (fuzzy.isNotEmpty()) {
                val best = fuzzy.minOf { it.second }
                return fuzzy.filter { it.second == best }.map { it.first }
            }
        }
        return emptyList()
    }
}
