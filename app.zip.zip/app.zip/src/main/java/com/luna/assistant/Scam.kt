package com.luna.assistant

object Scam {
    private val words = listOf(
        "otp", "kyc", "lottery", "you won", "claim now", "account blocked", "account suspended",
        "verify your account", "click here", "password", "gift card", "crypto", "guaranteed profit",
        "prize", "urgent", "free recharge", "inaam", "jeet gaye", "bank account", "pan card",
        "aadhaar", "refund", "customs", "package held"
    )
    private val urlRe = Regex("(https?://|www\\.|bit\\.ly|t\\.me/|wa\\.me/|tinyurl)\\S*", RegexOption.IGNORE_CASE)

    fun score(text: String): Int {
        val l = text.lowercase()
        var s = 0
        for (w in words) if (l.contains(w)) s++
        if (urlRe.containsMatchIn(l)) s++
        if (l.contains(".apk")) s += 2
        return s
    }

    fun isScam(text: String) = score(text) >= 2
}
