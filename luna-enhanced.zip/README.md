# Luna / Friday — Phone Assistant

An Android phone-assistant project with voice/text commands, provider-based AI chat, contact-aware calling and messages, busy-mode auto-replies, caller handling, app/permission review, and heuristic scam-message alerts.

## Build an APK on GitHub

1. Create/open your GitHub repository.
2. Extract **all contents** of this ZIP directly into the repository root. Keep the `.github/workflows/build.yml` path intact. Do not upload this ZIP as a file named `luna.zip`.
3. Commit and push the files to GitHub. The workflow starts automatically; you can also open **Actions → Build Luna APK → Run workflow**.
4. Open the finished workflow run, scroll to **Artifacts**, and download **Luna-APK**. Extract the artifact ZIP to get `app-debug.apk`.

The workflow builds a **debug APK** for testing. It is not a Play Store release build and does not contain a signing key. Keep your own release signing key private if you later publish the app.

## Configure AI

Open **Settings**, choose a provider, enter your own API key, and tap **Test AI**. Keys are not included in this source project. Gemini's default model is `gemini-3.8-flash`; known old Gemini defaults are migrated automatically. For the Anthropic workspace error, enter the actual Workspace ID from Anthropic Console if the API key requires it, or use a key scoped to that workspace. A workspace ID cannot be guessed by the app.

## Contacts and messaging

Grant only the permissions you need in **Access**. Contact matching prefers exact names and can handle multi-word names in commands such as `WhatsApp message to Rahul Khan I'll be there soon`. When a unique contact name is resolved, that phrase-to-number match is stored locally for later commands. Check the confirmation dialog before sending messages/calls.

WhatsApp auto-send requires WhatsApp installed and the optional Luna Accessibility service enabled in Android Settings. The service only presses Send when the requested draft text is visibly present; if it cannot verify the text, it does not tap Send and the request times out. Android/WhatsApp changes can still affect automation, so check the first sends manually.

Busy-mode replies require notification access and the relevant permissions/settings. The scam guard uses message-pattern heuristics and app-permission counts; it is **not** a full malware scanner and cannot guarantee that an app or message is safe. Availability of call rejection, background automation, and permissions varies by Android version and phone manufacturer.

## Current package

- Application ID: `com.luna.assistant`
- Minimum Android: Android 8.0 (API 26)
- Target/compile SDK: 34
- Version: 1.1
- Default AI/voice language: English (US)
